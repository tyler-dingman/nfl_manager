# Firebase Android tester build preparation — September 28, 2026

Status: Android source project and release JavaScript/assets prepared. **A new APK has NOT been compiled.** The attached bundle ZIP is not uploadable to Firebase App Distribution.

Completed:
- Refreshed Android native project with Expo prebuild (no dependency install or Gradle compilation).
- Exported production Android Hermes bundle and 81 assets successfully to `apps/mobile/dist/firebase-test`.
- Passed mobile TypeScript validation.
- Enabled isolated `test@gmail.com` / `test` login in internal Firebase builds. Default/store builds keep it disabled. Real accounts use the production HTTPS API; fixtures remain off.
- Updated tester version code in `apps/mobile/eas.json` and generated Android project.
- Includes current native screens, onboarding, notification preferences, white headings, Home fades, both launch concepts, and half-speed Field default with white yard numbers.

Remaining on a machine with sufficient build space:

```sh
cd apps/mobile
npm run android:firebase:build
```

This performs backend readiness checks, native prebuild and signed release APK compilation. It retains the existing local signing key. Upload the newly generated `apps/mobile/android/app/build/outputs/apk/release/app-release.apk` to Firebase App Distribution after compilation succeeds.

The APK currently at that path is dated September 27, 2026 at 20:22 and predates these changes. It was not replaced or relabelled. Native compilation and physical Android verification are deliberately deferred due to the user's disk-space instruction. Do not patch the old APK with this bundle: the new time-picker native module also requires compilation.

`down-distance-android-bundle.zip` contains the validated Hermes bundle, assets, export metadata and this note for handoff/reference. Source changes remain in the working tree; no commit or Firebase upload was performed.
